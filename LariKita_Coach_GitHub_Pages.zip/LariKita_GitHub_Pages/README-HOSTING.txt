LariKita Coach — paket siap hosting

1. Upload semua file di folder ini ke hosting statis HTTPS (file index.html harus berada di root situs).
2. Buka URL HTTPS situs tersebut dan uji di Chrome Android.
3. Untuk membuat paket Android, buka https://www.pwabuilder.com lalu masukkan URL situs. Pilih Package for stores > Android > Generate Package.
4. Untuk uji pribadi, pilih opsi Android yang menghasilkan APK signed/test package jika tersedia. Unduh paket, ekstrak ZIP, lalu instal APK di HP. Android mungkin meminta izin Install unknown apps untuk browser/file manager yang dipakai.

Aplikasi ini masih prototipe. Input manual, tidak ada GPS. Data disimpan lokal di browser/perangkat dan tidak otomatis tersinkron antarperangkat. AI Coach saat ini demo berbasis aturan lokal, bukan AI online.
